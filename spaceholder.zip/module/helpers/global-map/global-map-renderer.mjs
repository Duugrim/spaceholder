import { BiomeResolver } from './global-map-biome-resolver.mjs';

/**
 * Global Map Renderer
 * Pure visualization layer - renders unified grid to canvas
 * Does NOT process or modify data, only displays it
 */
export class GlobalMapRenderer {
  constructor() {
    this.container = null; // PIXI.Container for rendering
    this.isVisible = false;
    this.currentGrid = null; // Reference to current grid being rendered
    this.currentMetadata = null;
    // Separate render modes for heights and biomes
    this.heightsMode = 'contours-bw'; // 'contours-bw', 'contours', 'cells', 'off'
    this.biomesMode = 'fancy'; // 'fancy', 'fancyDebug', 'cells', 'off'
    this.biomeResolver = new BiomeResolver(); // For dynamic biome determination
  }

  /**
   * Initialize renderer and set up canvas hooks
   */
  async initialize() {
    console.log('GlobalMapRenderer | Initializing...');

    // Load biome resolver config
    await this.biomeResolver.loadConfig();

    Hooks.on('canvasReady', async () => {
      await this.onCanvasReady();
    });

    if (canvas?.ready && canvas?.scene) {
      console.log('GlobalMapRenderer | Canvas already ready');
      setTimeout(async () => {
        await this.onCanvasReady();
      }, 100);
    }
  }

  /**
   * Called when canvas is ready - set up rendering container
   */
  async onCanvasReady() {
    console.log('GlobalMapRenderer | onCanvasReady');
    this.isVisible = false;
    this.setupContainer();
  }

  /**
   * Set up PIXI container on primary layer (under tokens)
   */
  setupContainer() {
    const primaryLayer = canvas.primary;

    if (!primaryLayer) {
      console.warn('GlobalMapRenderer | Primary layer not available');
      return;
    }

    // Clear existing container
    if (this.container) {
      this.container.destroy({ children: true });
    }

    this.container = new PIXI.Container();
    this.container.name = 'globalMapContainer';
    
    // Устанавливаем высокий zIndex, чтобы быть поверх фона, но под токенами
    this.container.zIndex = 1000;
    
    primaryLayer.addChild(this.container);
    
    // Включаем сортировку по zIndex для primary layer
    if (!primaryLayer.sortableChildren) {
      primaryLayer.sortableChildren = true;
      primaryLayer.sortChildren();
    }

    console.log('GlobalMapRenderer | Container set up on primary layer (under tokens) with zIndex 1000');
  }

  /**
   * Set heights render mode
   * @param {string} mode - 'contours-bw', 'contours', 'cells', 'off'
   */
  setHeightsMode(mode) {
    if (!['contours-bw', 'contours', 'cells', 'off'].includes(mode)) {
      console.warn(`GlobalMapRenderer | Invalid heights mode: ${mode}`);
      return;
    }
    this.heightsMode = mode;
    console.log(`GlobalMapRenderer | Heights mode set to: ${mode}`);
    // Re-render if data available
    if (this.currentGrid && this.currentMetadata) {
      this.render(this.currentGrid, this.currentMetadata);
    }
  }

  /**
   * Set biomes render mode
   * @param {string} mode - 'fancy', 'fancyDebug', 'cells', 'off'
   */
  setBiomesMode(mode) {
    if (!['fancy', 'fancyDebug', 'cells', 'off'].includes(mode)) {
      console.warn(`GlobalMapRenderer | Invalid biomes mode: ${mode}`);
      return;
    }
    this.biomesMode = mode;
    console.log(`GlobalMapRenderer | Biomes mode set to: ${mode}`);
    // Re-render if data available
    if (this.currentGrid && this.currentMetadata) {
      this.render(this.currentGrid, this.currentMetadata);
    }
  }

  /**
   * Render unified grid to canvas with separate biomes and heights modes
   * @param {Object} gridData - Unified grid {heights, biomes, rivers, rows, cols}
   * @param {Object} metadata - Grid metadata
   */
  async render(gridData, metadata) {
    if (!gridData || !gridData.heights) {
      console.warn('GlobalMapRenderer | No grid data to render');
      return;
    }

    console.log(`GlobalMapRenderer | Rendering grid (biomes: ${this.biomesMode}, heights: ${this.heightsMode})...`);

    // Store reference to current grid
    this.currentGrid = gridData;
    this.currentMetadata = metadata;

    // Make sure container exists
    if (!this.container) {
      this.setupContainer();
    }

    // Clear previous rendering
    this.container.removeChildren();

    // Render biomes layer
    if (this.biomesMode !== 'off') {
      this._renderBiomesLayer(gridData, metadata);
    }

    // Render heights layer
    if (this.heightsMode !== 'off') {
      this._renderHeightsLayer(gridData, metadata);
    }

    // Render rivers layer (always on top)
    if (gridData.rivers) {
      this._renderRiversLayer(gridData, metadata);
    }

    this.isVisible = true;
    console.log(`GlobalMapRenderer | ✓ Rendered ${gridData.rows}x${gridData.cols} grid`);
  }

  /**
   * Render biomes layer based on current biomesMode
   * @private
   */
  _renderBiomesLayer(gridData, metadata) {
    switch (this.biomesMode) {
      case 'fancy':
        this._renderBiomesSmooth(gridData, metadata, false); // No borders
        break;
      case 'fancyDebug':
        this._renderBiomesSmooth(gridData, metadata, true); // With borders
        break;
      case 'cells':
        this._renderBiomesCells(gridData, metadata);
        break;
    }
  }

  /**
   * Render heights layer based on current heightsMode
   * @private
   */
  _renderHeightsLayer(gridData, metadata) {
    switch (this.heightsMode) {
      case 'contours-bw':
        this._renderHeightContoursBW(gridData, metadata);
        break;
      case 'contours':
        this._renderHeightContours(gridData, metadata);
        break;
      case 'cells':
        this._renderHeightCells(gridData, metadata);
        break;
    }
  }

  /**
   * Render biomes with smooth boundaries
   * @param {boolean} drawBorders - Whether to draw biome borders
   * @private
   */
  _renderBiomesSmooth(gridData, metadata, drawBorders = false) {
    const { biomes, moisture, temperature, heights, rows, cols } = gridData;
    const { cellSize, bounds } = metadata;

    // Prefer explicit biomes array; fall back to legacy moisture/temperature
    let biomeIds;
    if (biomes && biomes.length === rows * cols) {
      biomeIds = biomes;
    } else if (moisture && temperature) {
      biomeIds = new Uint8Array(rows * cols);
      for (let i = 0; i < rows * cols; i++) {
        biomeIds[i] = this.biomeResolver.getBiomeId(moisture[i], temperature[i]);
      }
    } else {
      return;
    }

    if (!biomeIds || biomeIds.length === 0) {
      console.log('GlobalMapRenderer | No biomes to render');
      return;
    }

    console.log('GlobalMapRenderer | Rendering biomes with smooth boundaries...');

    // Build per-biome cell lists in one pass
    const uniqueBiomes = new Set();
    const biomeCells = new Map(); // biomeId -> Array<cellIndex>

    for (let i = 0; i < rows * cols; i++) {
      const biomeId = biomeIds[i];
      uniqueBiomes.add(biomeId);
      let arr = biomeCells.get(biomeId);
      if (!arr) {
        arr = [];
        biomeCells.set(biomeId, arr);
      }
      arr.push(i);
    }

    const sortedBiomes = Array.from(uniqueBiomes).sort((a, b) => {
      const rankA = this.biomeResolver.getBiomeRank(a);
      const rankB = this.biomeResolver.getBiomeRank(b);
      if (rankA !== rankB) return rankA - rankB;
      return a - b;
    });

    console.log(`GlobalMapRenderer | Found ${sortedBiomes.length} unique biomes`);

    // Render biomes in deterministic rank order.
    // IMPORTANT: to avoid gaps after smoothing at multi-biome junctions, we slightly expand each biome
    // into neighboring (not-yet-processed) cells. This creates controlled overlaps that are resolved by
    // render rank ordering.
    const paintedCore = new Set();

    for (const biomeId of sortedBiomes) {
      const cells = biomeCells.get(biomeId);
      if (!cells || cells.length === 0) continue;

      const drawSet = new Set(cells);

      // Expand into 8-neighborhood ring around the biome, but never into already-painted core cells
      // (prevents later biomes from overwriting earlier biome ownership too aggressively).
      for (const cellIdx of cells) {
        const row = Math.floor(cellIdx / cols);
        const col = cellIdx % cols;

        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            if (dr === 0 && dc === 0) continue;

            const nRow = row + dr;
            const nCol = col + dc;
            if (nRow < 0 || nRow >= rows || nCol < 0 || nCol >= cols) continue;

            const nIdx = nRow * cols + nCol;
            if (paintedCore.has(nIdx)) continue;
            if (biomeIds[nIdx] === biomeId) continue;

            drawSet.add(nIdx);
          }
        }
      }

      this._renderBiomeRegionLayered(Array.from(drawSet), rows, cols, bounds, cellSize, biomeId);

      for (const cellIdx of cells) {
        paintedCore.add(cellIdx);
      }
    }

    // Optional: Draw smooth borders between biomes
    if (drawBorders) {
      this._drawBiomeBorders(biomeIds, rows, cols, bounds, cellSize, uniqueBiomes);
    }

    console.log('GlobalMapRenderer | ✓ Smooth biome boundaries rendered');
  }

  /**
   * Render biomes using wave-based approach at cluster level
   * Draws clusters in order of connectivity, starting from wettest biome
   * @private
   */
  _renderBiomesWaveBased(biomeIds, uniqueBiomes, rows, cols, bounds, cellSize) {
    // Build all clusters for all biomes first
    const allClusters = []; // Array of {biomeId, cluster: [cell indices], neighbors: Set}
    
    for (const biomeId of uniqueBiomes) {
      const biomeCells = [];
      for (let i = 0; i < rows * cols; i++) {
        if (biomeIds[i] === biomeId) {
          biomeCells.push(i);
        }
      }
      
      if (biomeCells.length === 0) continue;
      
      const clusters = this._findConnectedClusters(biomeCells, rows, cols);
      
      for (const cluster of clusters) {
        allClusters.push({
          biomeId,
          cluster,
          id: `${biomeId}_${allClusters.length}` // Unique cluster ID
        });
      }
    }
    
    console.log(`GlobalMapRenderer | Total clusters across all biomes: ${allClusters.length}`);
    
    // Find starting cluster (from wettest biome)
    const sortedBiomes = Array.from(uniqueBiomes).sort((a, b) => {
      const paramsA = this.biomeResolver.getParametersFromBiomeId(a);
      const paramsB = this.biomeResolver.getParametersFromBiomeId(b);
      if (paramsA.moisture !== paramsB.moisture) {
        return paramsB.moisture - paramsA.moisture;
      }
      return paramsA.temperature - paramsB.temperature;
    });
    
    const startBiomeId = sortedBiomes[0];
    const startCluster = allClusters.find(c => c.biomeId === startBiomeId);
    
    if (!startCluster) {
      console.warn('GlobalMapRenderer | No starting cluster found');
      return;
    }
    
    // Track rendered cells and processed clusters
    const pastBiomes = new Set(); // Rendered cells
    const processedClusters = new Set(); // Cluster IDs already drawn
    const clusterQueue = [startCluster]; // Queue of clusters to process
    
    // Process clusters in waves
    while (clusterQueue.length > 0) {
      const currentCluster = clusterQueue.shift();
      
      if (processedClusters.has(currentCluster.id)) {
        continue;
      }
      
      processedClusters.add(currentCluster.id);
      
      // Log cluster being drawn
      const biomeParams = this.biomeResolver.getParametersFromBiomeId(currentCluster.biomeId);
      const biomeColor = this.biomeResolver.getBiomeColor(currentCluster.biomeId);
      const colorHex = '#' + biomeColor.toString(16).padStart(6, '0').toUpperCase();
      
      console.log(`GlobalMapRenderer | Drawing cluster: %c${biomeParams.name}%c (ID: ${currentCluster.biomeId}, Cluster: ${currentCluster.id})`,
        `color: ${colorHex}; font-weight: bold;`,
        'color: inherit; font-weight: normal;');
      
      // Find neighboring cells not in pastBiomes
      const addBiome = new Set();
      const neighboringClusterIds = new Set();
      
      for (const idx of currentCluster.cluster) {
        const row = Math.floor(idx / cols);
        const col = idx % cols;
        
        // Check all 8 neighbors
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            if (dr === 0 && dc === 0) continue;
            
            const newRow = row + dr;
            const newCol = col + dc;
            
            if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols) {
              const neighborIdx = newRow * cols + newCol;
              
              // Find which cluster this neighbor belongs to
              if (biomeIds[neighborIdx] !== currentCluster.biomeId) {
                for (const otherCluster of allClusters) {
                  if (otherCluster.cluster.includes(neighborIdx) && !processedClusters.has(otherCluster.id)) {
                    neighboringClusterIds.add(otherCluster.id);
                    break;
                  }
                }
              }
              
              // Expand into unrendered cells
              if (!pastBiomes.has(neighborIdx)) {
                addBiome.add(neighborIdx);
              }
            }
          }
        }
      }
      
      // Combine cluster and expansion for drawing
      const drawBiome = [...currentCluster.cluster, ...Array.from(addBiome)];
      
      // Draw this cluster
      this._renderBiomeRegionLayered(drawBiome, rows, cols, bounds, cellSize, currentCluster.biomeId);
      
      // Mark cells as rendered
      for (const idx of currentCluster.cluster) {
        pastBiomes.add(idx);
      }
      
      // Add neighboring clusters to queue
      for (const neighborClusterId of neighboringClusterIds) {
        const neighborCluster = allClusters.find(c => c.id === neighborClusterId);
        if (neighborCluster && !clusterQueue.some(c => c.id === neighborClusterId)) {
          clusterQueue.push(neighborCluster);
        }
      }
    }
    
    // Process any remaining unprocessed clusters (disconnected regions)
    for (const cluster of allClusters) {
      if (!processedClusters.has(cluster.id)) {
        console.warn(`GlobalMapRenderer | Cluster ${cluster.id} was not connected, processing separately`);
        clusterQueue.push(cluster);
      }
    }
  }

  /**
   * Find connected clusters (components) in a set of cells
   * Uses flood-fill algorithm with 8-connectivity (including diagonals)
   * @private
   */
  _findConnectedClusters(cells, rows, cols) {
    if (cells.length === 0) return [];
    
    const cellSet = new Set(cells);
    const visited = new Set();
    const clusters = [];
    
    // Helper: Get 8 neighbors (including diagonals)
    const getNeighbors = (idx) => {
      const row = Math.floor(idx / cols);
      const col = idx % cols;
      const neighbors = [];
      
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          
          const newRow = row + dr;
          const newCol = col + dc;
          
          if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols) {
            neighbors.push(newRow * cols + newCol);
          }
        }
      }
      
      return neighbors;
    };
    
    // Flood-fill to find each cluster
    for (const startIdx of cells) {
      if (visited.has(startIdx)) continue;
      
      // BFS to find all connected cells
      const cluster = [];
      const queue = [startIdx];
      visited.add(startIdx);
      
      while (queue.length > 0) {
        const idx = queue.shift();
        cluster.push(idx);
        
        // Check neighbors
        for (const neighborIdx of getNeighbors(idx)) {
          if (cellSet.has(neighborIdx) && !visited.has(neighborIdx)) {
            visited.add(neighborIdx);
            queue.push(neighborIdx);
          }
        }
      }
      
      clusters.push(cluster);
    }
    
    return clusters;
  }

  /**
   * Render a biome region using layered filling approach
   * Creates smooth contours using marching squares
   * @private
   */
  _renderBiomeRegionLayered(cellIndices, rows, cols, bounds, cellSize, biomeId) {
    if (cellIndices.length === 0) return;
    
    const color = this.biomeResolver.getBiomeColor(biomeId);
    
    // Create EXPANDED binary grid with padding (to handle edges correctly)
    // Add 1 cell padding on all sides filled with 0
    const paddedRows = rows + 2;
    const paddedCols = cols + 2;
    const paddedGrid = new Float32Array(paddedRows * paddedCols); // Default 0
    
    // Fill padded grid (offset by 1)
    for (const idx of cellIndices) {
      const row = Math.floor(idx / cols);
      const col = idx % cols;
      const paddedIdx = (row + 1) * paddedCols + (col + 1);
      paddedGrid[paddedIdx] = 1.0;
    }
    
    // Adjust bounds for padded grid
    const paddedBounds = {
      minX: bounds.minX - cellSize,
      minY: bounds.minY - cellSize,
      maxX: bounds.maxX + cellSize,
      maxY: bounds.maxY + cellSize
    };
    
    // Use marching squares on padded grid
    const contourSegments = this._marchingSquares(paddedGrid, paddedRows, paddedCols, paddedBounds, cellSize, 0.5);

    if (contourSegments.length === 0) {
      return; // No boundaries for this biome
    }

    // Build contour paths from segments
    const contours = this._buildContourPaths(contourSegments);
    
    // Smooth contours using Chaikin's algorithm
    const smoothedContours = contours.map(path => this._smoothContour(path, 2));

    // Check if this biome has a pattern config
    const patternConfig = this.biomeResolver.getBiomePattern(biomeId);

    if (patternConfig) {
      // Draw with pattern using config
      this._drawBiomeWithPattern(smoothedContours, color, bounds, cellSize, biomeId, patternConfig);
    } else {
      // Draw filled regions (default behavior)
      const graphics = new PIXI.Graphics();
      graphics.beginFill(color, 1.0);
      this._drawContoursWithHoles(graphics, smoothedContours);
      graphics.endFill();

      this.container.addChild(graphics);
    }
  }

  /**
   * Draw biome region with pattern instead of solid fill
   * @private
   */
  _drawBiomeWithPattern(smoothedContours, color, bounds, cellSize, biomeId, patternConfig) {
    // 1. Сначала рисуем заливку основным цветом
    const baseGraphics = new PIXI.Graphics();
    baseGraphics.beginFill(color, 1.0);
    this._drawContoursWithHoles(baseGraphics, smoothedContours);
    baseGraphics.endFill();
    this.container.addChild(baseGraphics);
    
    // 2. Вычисляем реальный bounding box биома из контуров
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const contour of smoothedContours) {
      for (const point of contour) {
        if (point.x < minX) minX = point.x;
        if (point.y < minY) minY = point.y;
        if (point.x > maxX) maxX = point.x;
        if (point.y > maxY) maxY = point.y;
      }
    }
    const biomeBounds = { minX, minY, maxX, maxY };
    
    // 3. Создаём контейнер для паттерна с маской
    const patternContainer = new PIXI.Container();
    
    // 4. Маска для паттерна (та же форма биома)
    const mask = new PIXI.Graphics();
    mask.beginFill(0xFFFFFF);
    this._drawContoursWithHoles(mask, smoothedContours);
    mask.endFill();
    
    // 5. Рисуем паттерн согласно конфигурации
    const pattern = new PIXI.Graphics();
    
    // Извлекаем параметры из конфига с значениями по умолчанию
    const darkenFactor = patternConfig.darkenFactor ?? 0.4;
    const opacity = patternConfig.opacity ?? 0.9;
    const spacing = patternConfig.spacing ?? 2.0;
    const lineWidth = patternConfig.lineWidth ?? 0.6;
    
    // Определяем цвет паттерна: используем кастомный цвет, если указан, иначе затемняем основной
    let patternColor;
    if (patternConfig.patternColor) {
      // Кастомный цвет из конфига (hex-строка)
      patternColor = parseInt(patternConfig.patternColor, 16);
    } else {
      // Затемнённый основной цвет биома
      patternColor = this._darkenColor(color, darkenFactor);
    }
    
    // Выбираем тип паттерна (используем biomeBounds вместо bounds всей карты)
    switch (patternConfig.type) {
      case 'circles':
        this._drawConcentricCirclesPattern(pattern, smoothedContours, biomeBounds, cellSize, patternColor, spacing, lineWidth, opacity);
        break;
      case 'diagonal':
        this._drawDiagonalLinesPattern(pattern, biomeBounds, cellSize, patternColor, spacing, lineWidth, opacity);
        break;
      case 'crosshatch':
        this._drawCrosshatchPattern(pattern, biomeBounds, cellSize, patternColor, spacing, lineWidth, opacity);
        break;
      case 'vertical':
        this._drawVerticalLinesPattern(pattern, biomeBounds, cellSize, patternColor, spacing, lineWidth, opacity);
        break;
      case 'horizontal':
        this._drawHorizontalLinesPattern(pattern, biomeBounds, cellSize, patternColor, spacing, lineWidth, opacity);
        break;
      case 'dots':
        this._drawDotsPattern(pattern, biomeBounds, cellSize, patternColor, spacing, lineWidth, opacity);
        break;
      case 'waves':
        this._drawWavesPattern(pattern, biomeBounds, cellSize, patternColor, spacing, lineWidth, opacity);
        break;
      case 'hexagons':
        this._drawHexagonsPattern(pattern, biomeBounds, cellSize, patternColor, spacing, lineWidth, opacity);
        break;
      case 'spots':
        this._drawRandomSpotsPattern(pattern, smoothedContours, biomeBounds, cellSize, patternColor, spacing, lineWidth, opacity, biomeId);
        break;
      default:
        // По умолчанию - диагональные линии
        this._drawDiagonalLinesPattern(pattern, biomeBounds, cellSize, patternColor, spacing, lineWidth, opacity);
    }
    
    // 6. Применяем маску к паттерну
    pattern.mask = mask;
    
    // 7. Добавляем всё на сцену
    patternContainer.addChild(mask);
    patternContainer.addChild(pattern);
    this.container.addChild(patternContainer);
  }

  /**
   * Draw diagonal lines pattern
   * @private
   */
  _drawDiagonalLinesPattern(graphics, bounds, cellSize, color, spacingMultiplier = 2.0, lineWidthMultiplier = 0.6, opacity = 0.9) {
    const spacing = cellSize * spacingMultiplier;
    const lineWidth = Math.max(6, cellSize * lineWidthMultiplier);
    const mapWidth = bounds.maxX - bounds.minX;
    const mapHeight = bounds.maxY - bounds.minY;
    const diagonal = Math.sqrt(mapWidth ** 2 + mapHeight ** 2);
    
    graphics.lineStyle(lineWidth, color, opacity);
    
    // Рисуем диагональные линии (\) сверху-слева вниз-вправо
    // Начинаем с верхнего левого угла, идём по диагонали вправо-вниз
    for (let offset = -diagonal; offset < diagonal * 2; offset += spacing) {
      // Линия начинается либо на левой границе, либо на верхней
      const startX = bounds.minX;
      const startY = bounds.minY + offset;
      
      // Линия заканчивается либо на правой границе, либо на нижней
      const endX = bounds.minX + diagonal;
      const endY = bounds.minY + offset - diagonal;
      
      graphics.moveTo(startX, startY);
      graphics.lineTo(endX, endY);
    }
  }

  /**
   * Draw concentric circles pattern
   * @private
   */
  _drawConcentricCirclesPattern(graphics, contours, bounds, cellSize, color, spacingMultiplier = 2.0, lineWidthMultiplier = 0.4, opacity = 0.9) {
    // Находим центр области биома
    let sumX = 0, sumY = 0, pointCount = 0;
    for (const contour of contours) {
      for (const point of contour) {
        sumX += point.x;
        sumY += point.y;
        pointCount++;
      }
    }
    
    if (pointCount === 0) return;
    
    const centerX = sumX / pointCount;
    const centerY = sumY / pointCount;
    
    // Находим максимальное расстояние от центра до границы
    let maxDistance = 0;
    for (const contour of contours) {
      for (const point of contour) {
        const dist = Math.sqrt((point.x - centerX) ** 2 + (point.y - centerY) ** 2);
        if (dist > maxDistance) maxDistance = dist;
      }
    }
    
    // Рисуем концентрические круги
    const spacing = cellSize * spacingMultiplier;
    const lineWidth = Math.max(4, cellSize * lineWidthMultiplier);
    
    graphics.lineStyle(lineWidth, color, opacity);
    
    for (let radius = spacing; radius <= maxDistance + spacing; radius += spacing) {
      graphics.drawCircle(centerX, centerY, radius);
    }
  }

  /**
   * Draw crosshatch pattern (diagonal lines in both directions)
   * @private
   */
  _drawCrosshatchPattern(graphics, bounds, cellSize, color, spacingMultiplier = 2.0, lineWidthMultiplier = 0.6, opacity = 0.9) {
    // Рисуем диагональные линии в обе стороны
    const spacing = cellSize * spacingMultiplier;
    const lineWidth = Math.max(3, cellSize * lineWidthMultiplier * 0.5); // Тоньше для сетки
    const mapWidth = bounds.maxX - bounds.minX;
    const mapHeight = bounds.maxY - bounds.minY;
    const diagonal = Math.sqrt(mapWidth ** 2 + mapHeight ** 2);
    
    graphics.lineStyle(lineWidth, color, opacity);
    
    // Линии в одну сторону (\) - сверху-слева вниз-вправо
    for (let offset = -diagonal; offset < diagonal * 2; offset += spacing) {
      const startX = bounds.minX;
      const startY = bounds.minY + offset;
      const endX = bounds.minX + diagonal;
      const endY = bounds.minY + offset - diagonal;
      
      graphics.moveTo(startX, startY);
      graphics.lineTo(endX, endY);
    }
    
    // Линии в другую сторону (/) - снизу-слева вверх-вправо
    for (let offset = -diagonal; offset < diagonal * 2; offset += spacing) {
      const startX = bounds.minX;
      const startY = bounds.maxY - offset;
      const endX = bounds.minX + diagonal;
      const endY = bounds.maxY - offset + diagonal;
      
      graphics.moveTo(startX, startY);
      graphics.lineTo(endX, endY);
    }
  }

  /**
   * Draw vertical lines pattern
   * @private
   */
  _drawVerticalLinesPattern(graphics, bounds, cellSize, color, spacingMultiplier = 2.0, lineWidthMultiplier = 0.6, opacity = 0.9) {
    const spacing = cellSize * spacingMultiplier;
    const lineWidth = Math.max(6, cellSize * lineWidthMultiplier);
    const mapWidth = bounds.maxX - bounds.minX;
    const mapHeight = bounds.maxY - bounds.minY;
    
    graphics.lineStyle(lineWidth, color, opacity);
    
    for (let x = bounds.minX; x <= bounds.maxX; x += spacing) {
      graphics.moveTo(x, bounds.minY);
      graphics.lineTo(x, bounds.maxY);
    }
  }

  /**
   * Draw horizontal lines pattern
   * @private
   */
  _drawHorizontalLinesPattern(graphics, bounds, cellSize, color, spacingMultiplier = 2.0, lineWidthMultiplier = 0.6, opacity = 0.9) {
    const spacing = cellSize * spacingMultiplier;
    const lineWidth = Math.max(6, cellSize * lineWidthMultiplier);
    const mapWidth = bounds.maxX - bounds.minX;
    const mapHeight = bounds.maxY - bounds.minY;
    
    graphics.lineStyle(lineWidth, color, opacity);
    
    for (let y = bounds.minY; y <= bounds.maxY; y += spacing) {
      graphics.moveTo(bounds.minX, y);
      graphics.lineTo(bounds.maxX, y);
    }
  }

  /**
   * Draw dots pattern
   * @private
   */
  _drawDotsPattern(graphics, bounds, cellSize, color, spacingMultiplier = 2.0, lineWidthMultiplier = 0.4, opacity = 0.9) {
    const spacing = cellSize * spacingMultiplier;
    const dotRadius = Math.max(2, cellSize * lineWidthMultiplier);
    
    graphics.beginFill(color, opacity);
    
    for (let y = bounds.minY; y <= bounds.maxY; y += spacing) {
      for (let x = bounds.minX; x <= bounds.maxX; x += spacing) {
        graphics.drawCircle(x, y, dotRadius);
      }
    }
    
    graphics.endFill();
  }

  /**
   * Draw waves pattern
   * @private
   */
  _drawWavesPattern(graphics, bounds, cellSize, color, spacingMultiplier = 2.0, lineWidthMultiplier = 0.6, opacity = 0.9) {
    const spacing = cellSize * spacingMultiplier;
    const lineWidth = Math.max(3, cellSize * lineWidthMultiplier);
    const waveHeight = cellSize * spacingMultiplier * 0.25; // Уменьшили амплитуду с 0.5 до 0.25
    const waveLength = cellSize * 4;
    
    graphics.lineStyle(lineWidth, color, opacity);
    
    const mapWidth = bounds.maxX - bounds.minX;
    const step = cellSize * 0.5; // Меньший шаг для более плавных волн
    
    for (let y = bounds.minY; y <= bounds.maxY; y += spacing) {
      let firstPoint = true;
      
      for (let x = bounds.minX; x <= bounds.maxX + step; x += step) {
        const phase = (x - bounds.minX) / waveLength * Math.PI * 2;
        const waveY = y + Math.sin(phase) * waveHeight;
        
        if (firstPoint) {
          graphics.moveTo(x, waveY);
          firstPoint = false;
        } else {
          graphics.lineTo(x, waveY);
        }
      }
    }
  }

  /**
   * Draw hexagons pattern
   * @private
   */
  _drawHexagonsPattern(graphics, bounds, cellSize, color, spacingMultiplier = 2.0, lineWidthMultiplier = 0.3, opacity = 0.9) {
    const hexSize = cellSize * spacingMultiplier;
    const lineWidth = Math.max(2, cellSize * lineWidthMultiplier);
    const hexWidth = hexSize * 2;
    const hexHeight = Math.sqrt(3) * hexSize;
    
    graphics.lineStyle(lineWidth, color, opacity);
    
    // Рисуем шестиугольники в шахматном порядке
    for (let row = 0; row * hexHeight <= bounds.maxY - bounds.minY + hexHeight; row++) {
      for (let col = 0; col * hexWidth * 0.75 <= bounds.maxX - bounds.minX + hexWidth; col++) {
        const x = bounds.minX + col * hexWidth * 0.75;
        const y = bounds.minY + row * hexHeight + (col % 2) * hexHeight / 2;
        
        this._drawHexagon(graphics, x, y, hexSize);
      }
    }
  }

  /**
   * Draw random spots pattern
   * @private
   */
  _drawRandomSpotsPattern(graphics, contours, bounds, cellSize, color, spacingMultiplier = 2.0, lineWidthMultiplier = 0.4, opacity = 0.9, seed = 0) {
    const spacing = cellSize * spacingMultiplier;
    const minRadius = Math.max(2, cellSize * lineWidthMultiplier * 0.5);
    const maxRadius = Math.max(4, cellSize * lineWidthMultiplier * 1.5);
    
    // Простой генератор псевдослучайных чисел с seed
    let random = seed + 12345;
    const seededRandom = () => {
      random = (random * 9301 + 49297) % 233280;
      return random / 233280;
    };
    
    graphics.beginFill(color, opacity);
    
    // Генерируем пятна на сетке с небольшим смещением
    for (let y = bounds.minY; y <= bounds.maxY; y += spacing) {
      for (let x = bounds.minX; x <= bounds.maxX; x += spacing) {
        // Смещение от сетки
        const offsetX = (seededRandom() - 0.5) * spacing * 0.8;
        const offsetY = (seededRandom() - 0.5) * spacing * 0.8;
        
        // Случайный размер пятна
        const radius = minRadius + seededRandom() * (maxRadius - minRadius);
        
        // Иногда пропускаем пятно для разнообразия
        if (seededRandom() > 0.3) {
          graphics.drawCircle(x + offsetX, y + offsetY, radius);
        }
      }
    }
    
    graphics.endFill();
  }

  /**
   * Draw a single hexagon
   * @private
   */
  _drawHexagon(graphics, centerX, centerY, size) {
    const angles = [0, 60, 120, 180, 240, 300];
    
    graphics.moveTo(
      centerX + size * Math.cos(0),
      centerY + size * Math.sin(0)
    );
    
    for (const angle of angles) {
      const rad = (angle * Math.PI) / 180;
      graphics.lineTo(
        centerX + size * Math.cos(rad),
        centerY + size * Math.sin(rad)
      );
    }
    
    graphics.closePath();
  }

  /**
   * Check if biome cluster touches any edge of the map
   * @private
   */
  _checkBiomeTouchesEdge(cellIndices, rows, cols) {
    for (const idx of cellIndices) {
      const row = Math.floor(idx / cols);
      const col = idx % cols;
      
      // Check if on any edge
      if (row === 0 || row === rows - 1 || col === 0 || col === cols - 1) {
        return true;
      }
    }
    return false;
  }

  /**
   * Add explicit boundary paths along map edges for biomes that touch them
   * @private
   */
  _addEdgeBoundaries(contours, cellIndices, rows, cols, bounds, cellSize) {
    // Find cells on each edge
    const topEdge = [];
    const bottomEdge = [];
    const leftEdge = [];
    const rightEdge = [];
    
    for (const idx of cellIndices) {
      const row = Math.floor(idx / cols);
      const col = idx % cols;
      
      if (row === 0) topEdge.push(col);
      if (row === rows - 1) bottomEdge.push(col);
      if (col === 0) leftEdge.push(row);
      if (col === cols - 1) rightEdge.push(row);
    }
    
    // Sort edges
    topEdge.sort((a, b) => a - b);
    bottomEdge.sort((a, b) => a - b);
    leftEdge.sort((a, b) => a - b);
    rightEdge.sort((a, b) => a - b);
    
    // Add edge paths to contours
    if (topEdge.length > 0) {
      const path = [];
      for (const col of topEdge) {
        const x = bounds.minX + col * cellSize;
        const y = bounds.minY;
        path.push({ x, y });
        path.push({ x: x + cellSize, y });
      }
      if (path.length > 0) contours.push(path);
    }
    
    if (bottomEdge.length > 0) {
      const path = [];
      for (const col of bottomEdge) {
        const x = bounds.minX + col * cellSize;
        const y = bounds.minY + rows * cellSize;
        path.push({ x, y });
        path.push({ x: x + cellSize, y });
      }
      if (path.length > 0) contours.push(path);
    }
    
    if (leftEdge.length > 0) {
      const path = [];
      for (const row of leftEdge) {
        const x = bounds.minX;
        const y = bounds.minY + row * cellSize;
        path.push({ x, y });
        path.push({ x, y: y + cellSize });
      }
      if (path.length > 0) contours.push(path);
    }
    
    if (rightEdge.length > 0) {
      const path = [];
      for (const row of rightEdge) {
        const x = bounds.minX + cols * cellSize;
        const y = bounds.minY + row * cellSize;
        path.push({ x, y });
        path.push({ x, y: y + cellSize });
      }
      if (path.length > 0) contours.push(path);
    }
  }

  /**
   * Draw smooth borders between different biomes
   * @private
   */
  _drawBiomeBorders(biomeIds, rows, cols, bounds, cellSize, uniqueBiomes) {
    // For each unique biome, draw its borders
    for (const biomeId of uniqueBiomes) {
      this._drawBiomeBorder(biomeIds, rows, cols, bounds, cellSize, biomeId);
    }
  }

  /**
   * Draw border for a single biome using marching squares
   * @private
   */
  _drawBiomeBorder(biomeIds, rows, cols, bounds, cellSize, targetBiomeId) {
    // Create binary grid for this biome (1 = this biome, 0 = other)
    const binaryGrid = new Float32Array(rows * cols);
    for (let i = 0; i < biomeIds.length; i++) {
      binaryGrid[i] = biomeIds[i] === targetBiomeId ? 1.0 : 0.0;
    }

    // Use marching squares to find contours at threshold 0.5
    const contourSegments = this._marchingSquares(binaryGrid, rows, cols, bounds, cellSize, 0.5);

    if (contourSegments.length === 0) {
      return; // No boundaries for this biome
    }

    // Build and smooth contour paths
    const contours = this._buildContourPaths(contourSegments);
    const smoothedContours = contours.map(path => this._smoothContour(path, 2));

    // Draw border lines (not filled regions)
    const graphics = new PIXI.Graphics();
    const color = this.biomeResolver.getBiomeColor(targetBiomeId);
    
    // Draw darker border line
    graphics.lineStyle(1.5, this._darkenColor(color, 0.3), 0.6);
    for (const contour of smoothedContours) {
      if (contour.length < 3) continue;

      graphics.moveTo(contour[0].x, contour[0].y);
      for (let i = 1; i < contour.length; i++) {
        graphics.lineTo(contour[i].x, contour[i].y);
      }
      graphics.closePath();
    }

    this.container.addChild(graphics);
  }

  /**
   * Darken a color by a factor
   * @private
   */
  _darkenColor(color, factor) {
    const r = (color >> 16) & 0xFF;
    const g = (color >> 8) & 0xFF;
    const b = color & 0xFF;
    
    const newR = Math.floor(r * (1 - factor));
    const newG = Math.floor(g * (1 - factor));
    const newB = Math.floor(b * (1 - factor));
    
    return (newR << 16) | (newG << 8) | newB;
  }

  /**
   * Render a single biome region with smooth boundaries
   * @private
   */
  _renderBiomeRegion(biomeIds, rows, cols, bounds, cellSize, targetBiomeId, color) {
    const graphics = new PIXI.Graphics();

    // Create binary grid for this biome (1 = this biome, 0 = other)
    const binaryGrid = new Float32Array(rows * cols);
    for (let i = 0; i < biomeIds.length; i++) {
      binaryGrid[i] = biomeIds[i] === targetBiomeId ? 1.0 : 0.0;
    }

    // Use marching squares to find contours at threshold 0.5
    const contourSegments = this._marchingSquares(binaryGrid, rows, cols, bounds, cellSize, 0.5);

    if (contourSegments.length === 0) {
      return; // No boundaries for this biome
    }

    // 3. Build contour paths from segments
    const contours = this._buildContourPaths(contourSegments);

    // 4. Smooth contours using Chaikin's algorithm
    const smoothedContours = contours.map(path => this._smoothContour(path, 2));

    // 5. Draw filled regions
    graphics.beginFill(color, 1.0);
    for (const contour of smoothedContours) {
      if (contour.length < 3) continue;

      graphics.moveTo(contour[0].x, contour[0].y);
      for (let i = 1; i < contour.length; i++) {
        graphics.lineTo(contour[i].x, contour[i].y);
      }
      graphics.closePath();
    }
    graphics.endFill();

    this.container.addChild(graphics);
  }

  /**
   * Build contour paths from disconnected segments
   * Connects segments into closed loops
   * @private
   */
  _buildContourPaths(segments) {
    if (segments.length === 0) return [];

    const paths = [];
    const used = new Set();
    const epsilon = 0.1; // Tolerance for point matching

    const pointsEqual = (p1, p2) => {
      return Math.abs(p1.x - p2.x) < epsilon && Math.abs(p1.y - p2.y) < epsilon;
    };

    for (let i = 0; i < segments.length; i++) {
      if (used.has(i)) continue;

      const path = [segments[i][0], segments[i][1]];
      used.add(i);

      // Try to extend path by finding connecting segments
      let extended = true;
      while (extended) {
        extended = false;

        for (let j = 0; j < segments.length; j++) {
          if (used.has(j)) continue;

          const lastPoint = path[path.length - 1];
          const seg = segments[j];

          // Check if segment connects to end of path
          if (pointsEqual(lastPoint, seg[0])) {
            path.push(seg[1]);
            used.add(j);
            extended = true;
            break;
          } else if (pointsEqual(lastPoint, seg[1])) {
            path.push(seg[0]);
            used.add(j);
            extended = true;
            break;
          }
        }
      }

      paths.push(path);
    }

    return paths;
  }

  /**
   * Smooth contour using Chaikin's corner-cutting algorithm
   * @private
   */
  _smoothContour(points, iterations = 2) {
    if (points.length < 3) return points;

    let smoothed = [...points];

    for (let iter = 0; iter < iterations; iter++) {
      const newPoints = [];

      for (let i = 0; i < smoothed.length; i++) {
        const p0 = smoothed[i];
        const p1 = smoothed[(i + 1) % smoothed.length];

        // Create two new points at 1/4 and 3/4 along the segment
        newPoints.push({
          x: 0.75 * p0.x + 0.25 * p1.x,
          y: 0.75 * p0.y + 0.25 * p1.y
        });
        newPoints.push({
          x: 0.25 * p0.x + 0.75 * p1.x,
          y: 0.25 * p0.y + 0.75 * p1.y
        });
      }

      smoothed = newPoints;
    }

    return smoothed;
  }

  /**
   * Draw contour paths to Graphics, preserving holes (nested contours).
   * Fixes cases when a biome fully surrounds another biome and would otherwise fill over it.
   * @private
   */
  _drawContoursWithHoles(graphics, contours) {
    if (!graphics || !contours || contours.length === 0) return;

    const validContours = contours.filter(c => c && c.length >= 3);
    if (validContours.length === 0) return;

    if (validContours.length === 1) {
      this._drawContourPath(graphics, validContours[0]);
      return;
    }

    // PIXI hole shapes must be defined immediately after the shape they cut.
    // So we must group holes by their parent contour (not just rely on depth ordering).
    const hierarchy = this._buildContourHierarchy(validContours);

    // Build children lists for hierarchy traversal
    const children = hierarchy.map(() => []);
    for (let i = 0; i < hierarchy.length; i++) {
      const p = hierarchy[i].parent;
      if (p !== -1) {
        children[p].push(i);
      }
    }

    // Deterministic ordering: larger roots first; smaller holes first
    for (let i = 0; i < children.length; i++) {
      children[i].sort((a, b) => hierarchy[a].area - hierarchy[b].area);
    }

    const roots = [];
    for (let i = 0; i < hierarchy.length; i++) {
      if (hierarchy[i].parent === -1) {
        roots.push(i);
      }
    }
    roots.sort((a, b) => hierarchy[b].area - hierarchy[a].area);

    const drawSolidWithHoles = (idx) => {
      const contour = hierarchy[idx]?.contour;
      if (!contour || contour.length < 3) return;

      // Draw the solid contour
      this._drawContourPath(graphics, contour);

      // Punch direct children as holes
      const holeIndices = children[idx] || [];
      for (const holeIdx of holeIndices) {
        const holeContour = hierarchy[holeIdx]?.contour;
        if (!holeContour || holeContour.length < 3) continue;

        graphics.beginHole();
        this._drawContourPath(graphics, holeContour);
        graphics.endHole();
      }

      // Draw islands inside each hole (grandchildren), recursively
      for (const holeIdx of holeIndices) {
        const islandIndices = children[holeIdx] || [];
        for (const islandIdx of islandIndices) {
          drawSolidWithHoles(islandIdx);
        }
      }
    };

    for (const rootIdx of roots) {
      drawSolidWithHoles(rootIdx);
    }
  }

  /**
   * Draw a single closed contour path.
   * @private
   */
  _drawContourPath(graphics, contour) {
    graphics.moveTo(contour[0].x, contour[0].y);
    for (let i = 1; i < contour.length; i++) {
      graphics.lineTo(contour[i].x, contour[i].y);
    }
    graphics.closePath();
  }

  /**
   * Build contour hierarchy (nesting) to identify holes.
   * @private
   */
  _buildContourHierarchy(contours) {
    const items = contours.map(contour => ({
      contour,
      parent: -1,
      area: this._calculatePolygonArea(contour),
      bounds: this._getContourBounds(contour)
    }));

    const eps = 0.5;
    const boundsContain = (outer, inner) => {
      return inner.minX >= outer.minX - eps &&
        inner.minY >= outer.minY - eps &&
        inner.maxX <= outer.maxX + eps &&
        inner.maxY <= outer.maxY + eps;
    };

    for (let i = 0; i < items.length; i++) {
      let parent = -1;
      let minArea = Infinity;

      for (let j = 0; j < items.length; j++) {
        if (i === j) continue;

        // Parent must be larger than child
        if (items[j].area <= items[i].area) continue;
        if (!boundsContain(items[j].bounds, items[i].bounds)) continue;

        if (this._isContourInsideContour(items[i].contour, items[j].contour)) {
          if (items[j].area < minArea) {
            minArea = items[j].area;
            parent = j;
          }
        }
      }

      items[i].parent = parent;
    }

    return items;
  }

  /**
   * Compute bounds of a contour.
   * @private
   */
  _getContourBounds(contour) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;

    for (const p of contour) {
      if (p.x < minX) minX = p.x;
      if (p.y < minY) minY = p.y;
      if (p.x > maxX) maxX = p.x;
      if (p.y > maxY) maxY = p.y;
    }

    return { minX, minY, maxX, maxY };
  }

  /**
   * Calculate polygon area (absolute).
   * @private
   */
  _calculatePolygonArea(polygon) {
    if (!polygon || polygon.length < 3) return 0;

    let area = 0;
    for (let i = 0; i < polygon.length; i++) {
      const j = (i + 1) % polygon.length;
      area += polygon[i].x * polygon[j].y;
      area -= polygon[j].x * polygon[i].y;
    }

    return Math.abs(area / 2);
  }

  /**
   * Check whether contour A is inside contour B.
   * @private
   */
  _isContourInsideContour(contourA, contourB) {
    const sampleCount = Math.min(5, contourA.length);
    for (let i = 0; i < sampleCount; i++) {
      if (!this._isPointInPolygonInclusive(contourA[i], contourB)) {
        return false;
      }
    }
    return true;
  }

  /**
   * Point-in-polygon test (ray casting), treating boundary points as inside.
   * @private
   */
  _isPointInPolygonInclusive(point, polygon, epsilon = 0.5) {
    if (!point || !polygon || polygon.length < 3) return false;

    // Boundary check (needed because contours may share borders exactly)
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      if (this._isPointOnSegment(point, polygon[j], polygon[i], epsilon)) return true;
    }

    // Ray casting
    let inside = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const xi = polygon[i].x;
      const yi = polygon[i].y;
      const xj = polygon[j].x;
      const yj = polygon[j].y;

      const intersect = ((yi > point.y) !== (yj > point.y))
        && (point.x < (xj - xi) * (point.y - yi) / (yj - yi) + xi);

      if (intersect) inside = !inside;
    }

    return inside;
  }

  /**
   * Check if point lies on segment AB within epsilon.
   * @private
   */
  _isPointOnSegment(point, a, b, epsilon = 0.5) {
    const px = point.x;
    const py = point.y;
    const ax = a.x;
    const ay = a.y;
    const bx = b.x;
    const by = b.y;

    const abx = bx - ax;
    const aby = by - ay;
    const apx = px - ax;
    const apy = py - ay;

    const abLenSq = abx * abx + aby * aby;
    const epsSq = epsilon * epsilon;

    // Degenerate segment
    if (abLenSq === 0) {
      const dx = px - ax;
      const dy = py - ay;
      return dx * dx + dy * dy <= epsSq;
    }

    const t = (apx * abx + apy * aby) / abLenSq;
    if (t < 0 || t > 1) return false;

    const closestX = ax + t * abx;
    const closestY = ay + t * aby;
    const dx = px - closestX;
    const dy = py - closestY;

    return dx * dx + dy * dy <= epsSq;
  }

  /**
   * Render biomes as simple colored cells
   * @private
   */
  _renderBiomesCells(gridData, metadata) {
    const { biomes, moisture, temperature, heights, rows, cols } = gridData;
    const { cellSize, bounds } = metadata;

    console.log('GlobalMapRenderer | Rendering biomes as cells...');
    const graphics = new PIXI.Graphics();

    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const idx = row * cols + col;

        const biomeId = (biomes && biomes.length === rows * cols)
          ? biomes[idx]
          : this.biomeResolver.getBiomeId(moisture?.[idx] ?? 0, temperature?.[idx] ?? 0);

        const color = this.biomeResolver.getBiomeColor(biomeId);

        // Draw cell centered at coordinate point (shift by half cell)
        const x = bounds.minX + col * cellSize - cellSize / 2;
        const y = bounds.minY + row * cellSize - cellSize / 2;

        graphics.beginFill(color, 1.0);
        graphics.drawRect(x, y, cellSize, cellSize);
        graphics.endFill();
      }
    }

    this.container.addChild(graphics);
  }

  /**
   * Render height contours (black and white)
   * @private
   */
  _renderHeightContoursBW(gridData, metadata) {
    const { heights, rows, cols } = gridData;
    const { cellSize, bounds, heightStats } = metadata;

    // Create contour levels (20 levels for better detail)
    const minHeight = heightStats.min;
    const maxHeight = heightStats.max;
    const range = maxHeight - minHeight;

    // Skip if flat map
    if (range < 0.1) {
      console.log('GlobalMapRenderer | Skipping height contours (flat map)');
      return;
    }

    const levels = [];
    for (let i = 1; i <= 20; i++) {
      const level = minHeight + (range * i / 20);
      levels.push({ level });
    }

    // Draw contours for each level (all black)
    for (const levelInfo of levels) {
      const segments = this._marchingSquares(heights, rows, cols, bounds, cellSize, levelInfo.level);
      this._drawContourSegmentsBW(segments, heights, rows, cols, bounds, cellSize);
    }
  }

  /**
   * Render height contours (colored)
   * @private
   */
  _renderHeightContours(gridData, metadata) {
    const { heights, rows, cols } = gridData;
    const { cellSize, bounds, heightStats } = metadata;

    // Create contour levels (20 levels for better detail)
    const minHeight = heightStats.min;
    const maxHeight = heightStats.max;
    const range = maxHeight - minHeight;

    // Skip if flat map
    if (range < 0.1) {
      console.log('GlobalMapRenderer | Skipping height contours (flat map)');
      return;
    }

    const levels = [];
    for (let i = 1; i <= 20; i++) {
      const level = minHeight + (range * i / 20);
      levels.push({
        level,
        color: this._heightToColor(i / 20),
      });
    }

    // Draw contours for each level
    for (const levelInfo of levels) {
      const segments = this._marchingSquares(heights, rows, cols, bounds, cellSize, levelInfo.level);
      this._drawContourSegments(segments, levelInfo.color, heights, rows, cols, bounds, cellSize);
    }
  }

  /**
   * Render heights as colored cells
   * @private
   */
  _renderHeightCells(gridData, metadata) {
    const { heights, rows, cols } = gridData;
    const { cellSize, bounds, heightStats } = metadata;

    const graphics = new PIXI.Graphics();

    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const idx = row * cols + col;
        const height = heights[idx];
        
        const normalized = this._normalizeValue(height, heightStats.min, heightStats.max);
        const color = this._heightToColor(normalized);
        
        // Draw cell centered at coordinate point (shift by half cell)
        const x = bounds.minX + col * cellSize - cellSize / 2;
        const y = bounds.minY + row * cellSize - cellSize / 2;
        
        graphics.beginFill(color, 0.7);
        graphics.drawRect(x, y, cellSize, cellSize);
        graphics.endFill();
      }
    }

    this.container.addChild(graphics);
  }

  /**
   * Render biomes as colored cells (base layer)
   * Dynamically determines biome from moisture/temperature
   * @private
   */
  _renderBiomesBase(gridData, metadata) {
    const { moisture, temperature, heights, rows, cols } = gridData;
    const { cellSize, bounds } = metadata;

    if (!moisture || !temperature || !this.showBiomes) {
      return;
    }

    // Check if there are any biomes to render
    const hasBiomes = moisture.some(m => m > 0) && temperature.some(t => t > 0);
    if (!hasBiomes) {
      console.log('GlobalMapRenderer | No biomes to render');
      return;
    }

    console.log('GlobalMapRenderer | Rendering biome base layer (dynamic)...');
    const graphics = new PIXI.Graphics();

    // Render biome cells
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const idx = row * cols + col;
        
        const moistureVal = moisture[idx];
        const temperatureVal = temperature[idx];
        const height = heights[idx];

        // Dynamically determine biome ID from moisture/temperature/height
        const biomeId = this.biomeResolver.getBiomeId(moistureVal, temperatureVal, height);

        // Draw cell centered at coordinate point (shift by half cell)
        const x = bounds.minX + col * cellSize - cellSize / 2;
        const y = bounds.minY + row * cellSize - cellSize / 2;

        // Get biome color
        const color = this.biomeResolver.getBiomeColor(biomeId);
        const alpha = 1.0; // Fully opaque

        graphics.beginFill(color, alpha);
        graphics.drawRect(x, y, cellSize, cellSize);
        graphics.endFill();
      }
    }

    this.container.addChild(graphics);
    console.log('GlobalMapRenderer | ✓ Biome base layer rendered');
  }

  /**
   * Render as contour lines using marching squares
   * @private
   */
  _renderContours(gridData, metadata) {
    const { heights, rows, cols } = gridData;
    const { cellSize, bounds, heightStats } = metadata;

    // First, render biomes as base layer with smooth boundaries
    this._renderBiomesSmooth(gridData, metadata);

    // Then render contour lines on top
    // Create contour levels (20 levels for better detail)
    const minHeight = heightStats.min;
    const maxHeight = heightStats.max;
    const range = maxHeight - minHeight;

    const levels = [];
    for (let i = 1; i <= 20; i++) {
      const level = minHeight + (range * i / 20);
      levels.push({
        level,
        color: this._heightToColor(i / 20),
      });
    }

    // Draw contours for each level
    for (const levelInfo of levels) {
      const segments = this._marchingSquares(heights, rows, cols, bounds, cellSize, levelInfo.level);
      this._drawContourSegments(segments, levelInfo.color, heights, rows, cols, bounds, cellSize);
    }
  }

  /**
   * Marching squares algorithm to extract contour segments
   * @private
   */
  _marchingSquares(heights, rows, cols, bounds, cellSize, threshold) {
    const segments = [];

    for (let row = 0; row < rows - 1; row++) {
      for (let col = 0; col < cols - 1; col++) {
        const x = bounds.minX + col * cellSize;
        const y = bounds.minY + row * cellSize;

        // Get corner values
        const v00 = heights[row * cols + col];
        const v10 = heights[row * cols + (col + 1)];
        const v01 = heights[(row + 1) * cols + col];
        const v11 = heights[(row + 1) * cols + (col + 1)];

        // Calculate case
        let caseValue = 0;
        if (v00 >= threshold) caseValue |= 1;
        if (v10 >= threshold) caseValue |= 2;
        if (v11 >= threshold) caseValue |= 4;
        if (v01 >= threshold) caseValue |= 8;

        // Get segments for this case
        const segs = this._getMarchingSquaresSegments(caseValue, x, y, cellSize, v00, v10, v01, v11, threshold);
        segments.push(...segs);
      }
    }

    return segments;
  }

  /**
   * Get line segments for marching squares case
   * @private
   */
  _getMarchingSquaresSegments(caseValue, x, y, size, v00, v10, v01, v11, threshold) {
    const segments = [];

    const lerp = (v1, v2) => {
      if (Math.abs(v2 - v1) < 0.0001) return 0.5;
      return (threshold - v1) / (v2 - v1);
    };

    const edges = {
      top: { x: x + size * lerp(v00, v10), y },
      right: { x: x + size, y: y + size * lerp(v10, v11) },
      bottom: { x: x + size * lerp(v01, v11), y: y + size },
      left: { x, y: y + size * lerp(v00, v01) },
    };

    switch (caseValue) {
      case 1: segments.push([edges.left, edges.top]); break;
      case 2: segments.push([edges.top, edges.right]); break;
      case 3: segments.push([edges.left, edges.right]); break;
      case 4: segments.push([edges.right, edges.bottom]); break;
      case 5:
        segments.push([edges.left, edges.top]);
        segments.push([edges.right, edges.bottom]);
        break;
      case 6: segments.push([edges.top, edges.bottom]); break;
      case 7: segments.push([edges.left, edges.bottom]); break;
      case 8: segments.push([edges.bottom, edges.left]); break;
      case 9: segments.push([edges.bottom, edges.top]); break;
      case 10:
        segments.push([edges.top, edges.right]);
        segments.push([edges.bottom, edges.left]);
        break;
      case 11: segments.push([edges.bottom, edges.right]); break;
      case 12: segments.push([edges.right, edges.left]); break;
      case 13: segments.push([edges.right, edges.top]); break;
      case 14: segments.push([edges.top, edges.left]); break;
    }

    return segments;
  }

  /**
   * Draw contour line segments (black only)
   * @private
   */
  _drawContourSegmentsBW(segments, heights, rows, cols, bounds, cellSize) {
    if (segments.length === 0) return;

    const graphics = new PIXI.Graphics();

    // Draw black contour lines
    graphics.lineStyle(1.5, 0x000000, 0.8);
    for (const segment of segments) {
      graphics.moveTo(segment[0].x, segment[0].y);
      graphics.lineTo(segment[1].x, segment[1].y);
    }

    // Draw slope direction marks (hachures)
    this._drawSlopeMarks(graphics, segments, heights, rows, cols, bounds, cellSize, 0x000000);

    this.container.addChild(graphics);
  }

  /**
   * Draw contour line segments with outline and slope direction marks (colored)
   * @private
   */
  _drawContourSegments(segments, color, heights, rows, cols, bounds, cellSize) {
    if (segments.length === 0) return;

    const graphics = new PIXI.Graphics();

    // Draw black outline first (for better visibility)
    graphics.lineStyle(2, 0x000000, 0.6);
    for (const segment of segments) {
      graphics.moveTo(segment[0].x, segment[0].y);
      graphics.lineTo(segment[1].x, segment[1].y);
    }

    // Draw colored contour lines
    graphics.lineStyle(1, color, 0.8);
    for (const segment of segments) {
      graphics.moveTo(segment[0].x, segment[0].y);
      graphics.lineTo(segment[1].x, segment[1].y);
    }

    // Draw slope direction marks (hachures)
    this._drawSlopeMarks(graphics, segments, heights, rows, cols, bounds, cellSize, color);

    this.container.addChild(graphics);
  }

  /**
   * Draw short lines indicating downslope direction
   * @private
   */
  _drawSlopeMarks(graphics, segments, heightValues, rows, cols, bounds, cellSize, color) {
    const hachureLength = 4;
    const hachureSpacing = 25;

    for (const segment of segments) {
      const dx = segment[1].x - segment[0].x;
      const dy = segment[1].y - segment[0].y;
      const length = Math.sqrt(dx * dx + dy * dy);

      if (length < 1) continue;

      // Number of marks along segment
      const numMarks = Math.floor(length / hachureSpacing);
      if (numMarks === 0) continue;

      // Unit tangent vector (along contour)
      const tx = dx / length;
      const ty = dy / length;

      // Perpendicular vector
      const nx1 = -ty;
      const ny1 = tx;
      const nx2 = ty;
      const ny2 = -tx;

      // Sample points along segment
      for (let i = 1; i <= numMarks; i++) {
        const t = i / (numMarks + 1);
        const px = segment[0].x + dx * t;
        const py = segment[0].y + dy * t;

        // Sample heights in both perpendicular directions
        const sampleDist = cellSize * 2;
        const h1 = this._sampleHeightAtPoint(px + nx1 * sampleDist, py + ny1 * sampleDist, heightValues, rows, cols, bounds, cellSize);
        const h2 = this._sampleHeightAtPoint(px + nx2 * sampleDist, py + ny2 * sampleDist, heightValues, rows, cols, bounds, cellSize);

        // Direction that goes downhill
        let markNx, markNy;
        if (h1 < h2) {
          markNx = nx1;
          markNy = ny1;
        } else {
          markNx = nx2;
          markNy = ny2;
        }

        // Draw mark pointing downhill
        const hx = px + markNx * hachureLength;
        const hy = py + markNy * hachureLength;

        graphics.lineStyle(1, 0x000000, 0.7);
        graphics.moveTo(px, py);
        graphics.lineTo(hx, hy);
      }
    }
  }

  /**
   * Sample height value from grid at point
   * @private
   */
  _sampleHeightAtPoint(x, y, heightValues, rows, cols, bounds, cellSize) {
    // Convert world coordinates to grid coordinates
    const col = (x - bounds.minX) / cellSize;
    const row = (y - bounds.minY) / cellSize;

    // Check bounds
    if (col < 0 || col >= cols - 1 || row < 0 || row >= rows - 1) {
      return 0;
    }

    // Bilinear interpolation
    const col0 = Math.floor(col);
    const row0 = Math.floor(row);
    const col1 = col0 + 1;
    const row1 = row0 + 1;

    const fx = col - col0;
    const fy = row - row0;

    const v00 = heightValues[row0 * cols + col0];
    const v10 = heightValues[row0 * cols + col1];
    const v01 = heightValues[row1 * cols + col0];
    const v11 = heightValues[row1 * cols + col1];

    return (1 - fx) * (1 - fy) * v00 +
           fx * (1 - fy) * v10 +
           (1 - fx) * fy * v01 +
           fx * fy * v11;
  }

  /**
   * Render as colored cells
   * @private
   */
  _renderCells(gridData, metadata, renderOptions) {
    const {
      mode = 'heights',
      heightColorFunc = null,
      biomeColorFunc = null,
      opacity = 0.7,
      cellBorder = false,
    } = renderOptions;

    const { heights, moisture, temperature, rows, cols } = gridData;
    const { cellSize, bounds } = metadata;

    const graphics = new PIXI.Graphics();

    // Render grid cells
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        const idx = row * cols + col;

        // Draw cell centered at coordinate point (shift by half cell)
        const x = bounds.minX + col * cellSize - cellSize / 2;
        const y = bounds.minY + row * cellSize - cellSize / 2;

        let color = 0xffffff; // Default white
        let alpha = opacity;

        if (mode === 'heights' || mode === 'both') {
          const height = heights[idx];

          if (heightColorFunc) {
            color = heightColorFunc(height, metadata.heightStats);
          } else {
            const normalized = this._normalizeValue(
              height,
              metadata.heightStats.min,
              metadata.heightStats.max
            );
            color = this._heightToColor(normalized);
          }

          alpha = opacity * 0.7;
        }

        if (mode === 'biomes' || mode === 'both') {
          // Dynamically determine biome from moisture/temperature
          const biomeId = this.biomeResolver.getBiomeId(
            moisture[idx],
            temperature[idx],
            heights[idx]
          );

          if (biomeColorFunc) {
            const biomeColor = biomeColorFunc(biomeId);
            color = biomeColor;
            alpha = opacity;
          } else {
            color = this.biomeResolver.getBiomeColor(biomeId);
            alpha = opacity;
          }
        }

        // Draw cell
        graphics.beginFill(color, alpha);
        graphics.drawRect(x, y, cellSize, cellSize);
        graphics.endFill();

        // Optional cell border
        if (cellBorder) {
          graphics.lineStyle(0.5, 0x000000, 0.3);
          graphics.drawRect(x, y, cellSize, cellSize);
        }
      }
    }

    this.container.addChild(graphics);
  }

  /**
   * Show renderer (make visible)
   */
  show() {
    if (this.container) {
      this.container.visible = true;
      this.isVisible = true;
      console.log('GlobalMapRenderer | Shown');
    }
  }

  /**
   * Hide renderer
   */
  hide() {
    if (this.container) {
      this.container.visible = false;
      this.isVisible = false;
      console.log('GlobalMapRenderer | Hidden');
    }
  }

  /**
   * Toggle visibility
   */
  toggle() {
    if (this.isVisible) {
      this.hide();
    } else {
      this.show();
    }
  }

  /**
   * Clear rendering
   */
  clear() {
    if (this.container) {
      this.container.removeChildren();
      this.isVisible = false;
      console.log('GlobalMapRenderer | Cleared');
    }
  }

  /**
   * Export the current rendered map (PIXI container) to an image Blob.
   * This exports the current render state (current modes, already-rendered graphics).
   *
   * @param {Object} [options]
   * @param {number} [options.width] - Export width in pixels (defaults to active scene width)
   * @param {number} [options.height] - Export height in pixels (defaults to active scene height)
   * @param {number} [options.scale=1] - Scale factor (1 = full size)
   * @param {'image/webp'|'image/png'} [options.mimeType='image/webp']
   * @param {number} [options.quality=0.92] - WebP quality 0..1
   * @returns {Promise<{blob: Blob, width: number, height: number}>}
   */
  async exportToBlob(options = {}) {
    const scene = canvas?.scene;
    if (!scene) {
      throw new Error('No active scene');
    }

    if (!this.container) {
      throw new Error('Renderer container not initialized');
    }

    const renderer = canvas?.app?.renderer;
    if (!renderer) {
      throw new Error('PIXI renderer not available');
    }

    const {
      width = scene.dimensions?.width,
      height = scene.dimensions?.height,
      scale = 1,
      mimeType = 'image/webp',
      quality = 0.92,
      allowDownscale = true,
    } = options;

    if (!width || !height) {
      throw new Error('Scene dimensions not available');
    }

    let requestedScale = Math.max(0.05, Math.min(4, Number(scale) || 1));

    // Guard against GPU texture size limits
    const maxSize = renderer.texture?.maxSize || renderer.gl?.getParameter(renderer.gl.MAX_TEXTURE_SIZE);
    if (maxSize) {
      const maxScaleX = maxSize / width;
      const maxScaleY = maxSize / height;
      const maxSafeScale = Math.max(0.01, Math.min(maxScaleX, maxScaleY));

      // Round down a bit to avoid floating-point edge cases
      const maxSafeScaleRounded = Math.floor(maxSafeScale * 1000) / 1000;

      if (requestedScale > maxSafeScaleRounded) {
        if (!allowDownscale) {
          const exportWidth = Math.max(1, Math.floor(width * requestedScale));
          const exportHeight = Math.max(1, Math.floor(height * requestedScale));
          throw new Error(`Export size ${exportWidth}x${exportHeight} exceeds max texture size ${maxSize}`);
        }
        requestedScale = maxSafeScaleRounded;
      }
    }

    const exportScale = requestedScale;
    const exportWidth = Math.max(1, Math.floor(width * exportScale));
    const exportHeight = Math.max(1, Math.floor(height * exportScale));

    if (maxSize && (exportWidth > maxSize || exportHeight > maxSize)) {
      throw new Error(`Export size ${exportWidth}x${exportHeight} exceeds max texture size ${maxSize}`);
    }

    const rt = PIXI.RenderTexture.create({
      width: exportWidth,
      height: exportHeight,
      resolution: 1,
    });

    // Temporarily detach from the canvas (to avoid pan/zoom transforms) and render in scene coordinates.
    const originalParent = this.container.parent;
    const originalVisible = this.container.visible;
    const originalX = this.container.x;
    const originalY = this.container.y;
    const originalScaleX = this.container.scale.x;
    const originalScaleY = this.container.scale.y;
    const originalRotation = this.container.rotation;

    const tempRoot = new PIXI.Container();

    try {
      this.container.visible = true;

      if (originalParent) {
        originalParent.removeChild(this.container);
      }
      tempRoot.addChild(this.container);

      // Reset transform to predictable export space
      this.container.x = 0;
      this.container.y = 0;
      this.container.rotation = 0;
      this.container.scale.set(exportScale, exportScale);

      renderer.render(this.container, { renderTexture: rt, clear: true });

      const extract = renderer.plugins?.extract || renderer.extract;
      if (!extract?.canvas) {
        throw new Error('PIXI extract plugin not available');
      }

      const exportCanvas = extract.canvas(rt);

      const blob = await new Promise((resolve, reject) => {
        const encoderOptions = mimeType === 'image/webp' ? quality : undefined;
        exportCanvas.toBlob((b) => {
          if (b) resolve(b);
          else reject(new Error('Failed to convert canvas to Blob'));
        }, mimeType, encoderOptions);
      });

      return { blob, width: exportWidth, height: exportHeight, scale: exportScale, maxSize };
    } finally {
      try {
        rt.destroy(true);
      } catch (e) {
        // ignore
      }

      try {
        tempRoot.removeChild(this.container);
      } catch (e) {
        // ignore
      }

      if (originalParent) {
        originalParent.addChild(this.container);
        if (originalParent.sortableChildren) {
          originalParent.sortChildren();
        }
      }

      this.container.visible = originalVisible;
      this.container.x = originalX;
      this.container.y = originalY;
      this.container.scale.set(originalScaleX, originalScaleY);
      this.container.rotation = originalRotation;
    }
  }

  /**
   * Normalize value to 0-1 range
   * @private
   */
  _normalizeValue(value, min, max) {
    if (max === min) return 0.5;
    return (value - min) / (max - min);
  }

  /**
   * Render rivers layer with smooth Bezier curves and variable width
   * @private
   */
  _renderRiversLayer(gridData, metadata) {
    const { rivers, biomes, moisture, temperature, rows, cols } = gridData;
    const { cellSize, bounds } = metadata;

    if (!rivers) return;

    // Rivers currently rely on ocean detection via legacy moisture/temperature.
    // If those arrays are missing (v4+ saves), derive them from biome IDs.
    let moistureIds = moisture;
    let temperatureIds = temperature;

    if ((!moistureIds || !temperatureIds) && biomes && biomes.length === rows * cols) {
      moistureIds = new Uint8Array(rows * cols);
      temperatureIds = new Uint8Array(rows * cols);

      for (let i = 0; i < rows * cols; i++) {
        const params = this.biomeResolver.getParametersFromBiomeId(biomes[i]);
        moistureIds[i] = params?.moisture ?? 0;
        temperatureIds[i] = params?.temperature ?? 0;
      }
    }

    if (!moistureIds || !temperatureIds) {
      console.warn('GlobalMapRenderer | Rivers: missing moisture/temperature and cannot derive from biomes');
      return;
    }

    // Count rivers for logging
    let riverCount = 0;
    for (let i = 0; i < rivers.length; i++) {
      if (rivers[i] === 1) riverCount++;
    }

    if (riverCount === 0) {
      console.log('GlobalMapRenderer | No rivers to render');
      return;
    }

    console.log(`GlobalMapRenderer | Rendering ${riverCount} river cells with Bezier curves...`);

    // Find all river paths (from ocean mouths to sources)
    const { paths: riverPaths, mainRiverCount, riverColors } = this._extractRiverPaths(rivers, moistureIds, temperatureIds, rows, cols);
    
    console.log(`GlobalMapRenderer | Found ${riverPaths.length} river paths (${mainRiverCount} main, ${riverPaths.length - mainRiverCount} branches)`);

    // Render each river path
    const graphics = new PIXI.Graphics();

    for (let i = 0; i < riverPaths.length; i++) {
      const path = riverPaths[i];
      // Первые mainRiverCount путей - основные реки, остальные - ветки
      const isSubRiver = i >= mainRiverCount;
      const riverColor = riverColors[i] || 0x3A9BD9; // Цвет от океана или дефолтный
      console.log(`GlobalMapRenderer | Drawing river ${i}: isSubRiver=${isSubRiver}, pathLength=${path.length}, color=${riverColor.toString(16)}`);
      this._drawRiverPath(graphics, path, bounds, cellSize, riverColor, isSubRiver);
    }

    this.container.addChild(graphics);
    console.log(`GlobalMapRenderer | ✓ Rivers rendered: ${riverPaths.length} paths`);
  }

  /**
   * Extract river paths from grid
   * Starts from ocean cells (moisture=6) and traces inland
   * Builds linear paths with proper ordering and handles branches
   * @private
   */
  _extractRiverPaths(rivers, moisture, temperature, rows, cols) {
    const paths = [];
    const riverColors = []; // Цвета рек (от океанов)
    const drawnCells = new Set(); // Клетки, уже нарисованные в каких-либо реках

    // Helper: get cell index
    const idx = (row, col) => row * cols + col;

    // Helper: check if cell is ocean (moisture = 6)
    const isOcean = (row, col) => {
      if (row < 0 || row >= rows || col < 0 || col >= cols) return false;
      return moisture[idx(row, col)] === 6;
    };

    // Helper: check if cell has river
    const hasRiver = (row, col) => {
      if (row < 0 || row >= rows || col < 0 || col >= cols) return false;
      return rivers[idx(row, col)] === 1;
    };

    // Helper: check if two cells are direct neighbors (share edge, not diagonal)
    const isDirectNeighbor = (cell1, cell2) => {
      const dr = Math.abs(cell1.row - cell2.row);
      const dc = Math.abs(cell1.col - cell2.col);
      return (dr === 1 && dc === 0) || (dr === 0 && dc === 1);
    };

    // Helper: check if two cells are neighbors (8-connectivity)
    const areNeighbors = (cell1, cell2) => {
      const dr = Math.abs(cell1.row - cell2.row);
      const dc = Math.abs(cell1.col - cell2.col);
      return dr <= 1 && dc <= 1 && (dr !== 0 || dc !== 0);
    };

    // Helper: get most aligned neighbor (continues in same direction)
    const getMostOppositeNeighbor = (current, prev, neighbors) => {
      if (neighbors.length === 0) return null;
      if (neighbors.length === 1) return neighbors[0];

      // If prev is same as current (no direction), just return first
      if (prev.row === current.row && prev.col === current.col) {
        return neighbors[0];
      }

      // Calculate direction vector from prev to current
      const dirRow = current.row - prev.row;
      const dirCol = current.col - prev.col;

      // Normalize direction (just for clarity, not strictly needed)
      const dirLen = Math.sqrt(dirRow * dirRow + dirCol * dirCol);
      const normDirRow = dirRow / dirLen;
      const normDirCol = dirCol / dirLen;

      // Find neighbor most aligned with this direction
      let bestNeighbor = neighbors[0];
      let bestDot = -Infinity;

      for (const neighbor of neighbors) {
        const nDirRow = neighbor.row - current.row;
        const nDirCol = neighbor.col - current.col;
        const nDirLen = Math.sqrt(nDirRow * nDirRow + nDirCol * nDirCol);
        const normNDirRow = nDirRow / nDirLen;
        const normNDirCol = nDirCol / nDirLen;
        
        // Dot product: 1 = same direction, -1 = opposite, 0 = perpendicular
        const dot = normDirRow * normNDirRow + normDirCol * normNDirCol;
        
        if (dot > bestDot) {
          bestDot = dot;
          bestNeighbor = neighbor;
        }
      }

      console.log(`GlobalMapRenderer | Selected neighbor (${bestNeighbor.row}, ${bestNeighbor.col}) with dot=${bestDot.toFixed(2)}`);
      return bestNeighbor;
    };

    // Step 1: Find all river mouths (river cells adjacent to ocean)
    const qRivers = [];
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        if (!hasRiver(row, col)) continue;
        
        // Check if adjacent to ocean
        let hasOceanNeighbor = false;
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            if (dr === 0 && dc === 0) continue;
            if (isOcean(row + dr, col + dc)) {
              hasOceanNeighbor = true;
              break;
            }
          }
          if (hasOceanNeighbor) break;
        }
        
        if (hasOceanNeighbor) {
          qRivers.push({ row, col });
        }
      }
    }

    console.log(`GlobalMapRenderer | Found ${qRivers.length} river mouths`);

    // Step 2: Process main rivers
    const qSubRivers = [];
    let mainRiverCount = 0;

    for (const mouth of qRivers) {
      const cellIdx = idx(mouth.row, mouth.col);
      if (drawnCells.has(cellIdx)) {
        console.log(`GlobalMapRenderer | Mouth at (${mouth.row}, ${mouth.col}) already drawn, skipping`);
        continue;
      }

      const riverPath = this._traceRiver(mouth, null, drawnCells, qSubRivers, {
        idx, isOcean, hasRiver, isDirectNeighbor, areNeighbors, getMostOppositeNeighbor,
        rows, cols
      }, null); // parentColor = null для основных рек

      console.log(`GlobalMapRenderer | Traced river from (${mouth.row}, ${mouth.col}), path length: ${riverPath ? riverPath.length : 0}`);

      if (riverPath && riverPath.length >= 2) {
        paths.push(riverPath);
        
        // Определяем цвет от океана
        const oceanColor = this._getOceanColorForMouth(mouth, moisture, temperature, rows, cols, idx);
        riverColors.push(oceanColor);
        
        // Передаём цвет всем веткам этой реки
        for (const subRiver of qSubRivers) {
          if (subRiver.parentColor === null) {
            subRiver.parentColor = oceanColor;
          }
        }
        
        mainRiverCount++; // Считаем только реально добавленные реки
      } else if (riverPath && riverPath.length === 1) {
        console.log(`GlobalMapRenderer | River path too short (1 cell), skipping`);
      }
    }

    // Step 3: Process sub-rivers (branches)
    console.log(`GlobalMapRenderer | Found ${qSubRivers.length} river branches`);

    for (const subRiver of qSubRivers) {
      const cellIdx = idx(subRiver.start.row, subRiver.start.col);
      if (drawnCells.has(cellIdx)) continue;

      const riverPath = this._traceRiver(subRiver.start, subRiver.parent, drawnCells, qSubRivers, {
        idx, isOcean, hasRiver, isDirectNeighbor, areNeighbors, getMostOppositeNeighbor,
        rows, cols
      }, subRiver.parentColor); // Передаём цвет родителя

      if (riverPath && riverPath.length >= 1) {
        // Добавляем родительскую клетку в начало пути для соединения
        riverPath.unshift(subRiver.parent);
        paths.push(riverPath);
        
        // Ветки наследуют цвет родительской реки
        riverColors.push(subRiver.parentColor || 0x3A9BD9);
      }
    }

    return { paths, mainRiverCount, riverColors };
  }

  /**
   * Get ocean color for river mouth
   * Determines color based on ocean biome adjacent to mouth
   * @private
   */
  _getOceanColorForMouth(mouth, moisture, temperature, rows, cols, idx) {
    // Найти соседние океаны
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const nRow = mouth.row + dr;
        const nCol = mouth.col + dc;
        
        if (nRow < 0 || nRow >= rows || nCol < 0 || nCol >= cols) continue;
        
        const nIdx = idx(nRow, nCol);
        const nMoisture = moisture[nIdx];
        
        // Проверяем, что это океан (moisture = 6)
        if (nMoisture === 6) {
          const nTemperature = temperature[nIdx];
          const oceanBiomeId = this.biomeResolver.getBiomeId(nMoisture, nTemperature, 0);
          const oceanColor = this.biomeResolver.getBiomeColor(oceanBiomeId);
          
          console.log(`GlobalMapRenderer | River mouth at (${mouth.row}, ${mouth.col}) uses ocean color from biome ${oceanBiomeId}: #${oceanColor.toString(16).padStart(6, '0')}`);
          return oceanColor;
        }
      }
    }
    
    // Дефолтный цвет воды
    return 0x3A9BD9;
  }

  /**
   * Trace a single river from start cell
   * @private
   */
  _traceRiver(start, prevCell, drawnCells, qSubRivers, helpers, parentColor) {
    const { idx, isOcean, hasRiver, isDirectNeighbor, areNeighbors, getMostOppositeNeighbor, rows, cols } = helpers;
    const path = [];
    let current = start;
    let prev = prevCell;
    let isFirstCell = (prev === null);
    let stepCount = 0;
    const maxSteps = 1000; // Защита от бесконечного цикла

    while (current && stepCount < maxSteps) {
      stepCount++;
      const cellIdx = idx(current.row, current.col);
      
      // Skip if already drawn
      if (drawnCells.has(cellIdx)) {
        break;
      }

      // Add to path and mark as drawn
      path.push(current);
      drawnCells.add(cellIdx);

      // Lookup neighbors
      const oceanNeighbors = [];
      const riverNeighbors = [];
      let totalRiverNeighbors = 0; // Сколько всего соседей-рек (включая уже нарисованные)

      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          const nRow = current.row + dr;
          const nCol = current.col + dc;
          if (nRow < 0 || nRow >= rows || nCol < 0 || nCol >= cols) continue;

          const neighbor = { row: nRow, col: nCol };
          const nIdx = idx(nRow, nCol);

          // Skip previous cell
          if (prev && prev.row === nRow && prev.col === nCol) continue;

          if (isOcean(nRow, nCol)) {
            oceanNeighbors.push({ ...neighbor, isDirect: isDirectNeighbor(current, neighbor) });
          } else if (hasRiver(nRow, nCol)) {
            totalRiverNeighbors++;
            if (!drawnCells.has(nIdx)) {
              riverNeighbors.push({ ...neighbor, isDirect: isDirectNeighbor(current, neighbor) });
            }
          }
        }
      }

      console.log(`GlobalMapRenderer | Cell (${current.row}, ${current.col}): oceans=${oceanNeighbors.length}, rivers=${riverNeighbors.length}, totalRivers=${totalRiverNeighbors}, prev=${prev ? `(${prev.row}, ${prev.col})` : 'null'}`);

      // Decision logic
      let nextCell = null;

      if (isFirstCell) {
        console.log(`GlobalMapRenderer | First cell logic: oceanNeighbors=${oceanNeighbors.length}, riverNeighbors=${riverNeighbors.length}`);
        
        // First cell: check for strait/channel pattern
        if (oceanNeighbors.length >= 2 && riverNeighbors.length === 0) {
          // Check if oceans are NOT neighbors to each other
          const ocean1 = oceanNeighbors[0];
          const ocean2 = oceanNeighbors[1];
          if (!areNeighbors(ocean1, ocean2)) {
            // This is a strait - just a connector, end here
            console.log(`GlobalMapRenderer | Detected strait at (${current.row}, ${current.col}), ending`);
            break;
          }
        }

        // Prefer direct ocean neighbor for mouth
        const directOcean = oceanNeighbors.find(n => n.isDirect);
        if (directOcean) {
          prev = directOcean; // Set ocean as prev for direction
          console.log(`GlobalMapRenderer | Set prev to direct ocean at (${prev.row}, ${prev.col})`);
        } else if (oceanNeighbors.length > 0) {
          prev = oceanNeighbors[0];
          console.log(`GlobalMapRenderer | Set prev to diagonal ocean at (${prev.row}, ${prev.col})`);
        }

        isFirstCell = false;
      }

      // Find next river cell
      if (riverNeighbors.length === 0) {
        // No river neighbors - check if this is end or another ocean mouth
        if (oceanNeighbors.length > 0) {
          console.log(`GlobalMapRenderer | River ends at another ocean at (${current.row}, ${current.col})`);
        } else {
          console.log(`GlobalMapRenderer | End of river at (${current.row}, ${current.col}), no more neighbors`);
        }
        break;
      } else if (riverNeighbors.length === 1) {
        // Single neighbor - continue
        nextCell = riverNeighbors[0];
      } else {
        // Multiple neighbors - junction
        // Choose most opposite to previous direction
        nextCell = getMostOppositeNeighbor(current, prev || current, riverNeighbors);

        // Add other branches to sub-rivers queue
        for (const neighbor of riverNeighbors) {
          if (neighbor.row !== nextCell.row || neighbor.col !== nextCell.col) {
            qSubRivers.push({ 
              start: neighbor, 
              parent: current,
              parentColor: parentColor // Наследуем цвет от текущей реки
            });
          }
        }
      }

      // Move to next cell
      prev = current;
      current = nextCell;
    }

    return path;
  }

  /**
   * Draw a single river path with smooth Bezier curves and variable width
   * Width decreases from mouth (wide) to source (narrow)
   * @private
   */
  _drawRiverPath(graphics, path, bounds, cellSize, color, isSubRiver = false) {
    if (path.length < 2) return;

    // Convert path cells to world coordinates
    const points = path.map(cell => ({
      x: bounds.minX + cell.col * cellSize,
      y: bounds.minY + cell.row * cellSize
    }));

    // Define width range
    // Для саб-рек начальная ширина меньше (они впадают в основную реку)
    const maxWidth = isSubRiver 
      ? Math.max(2, cellSize * 0.4) // Узкое устье для веток
      : Math.max(3, cellSize * 0.8); // Широкое устье для основных рек
    const minWidth = Math.max(1, cellSize * 0.15); // Narrow at source
    
    console.log(`GlobalMapRenderer | _drawRiverPath: isSubRiver=${isSubRiver}, maxWidth=${maxWidth.toFixed(2)}, minWidth=${minWidth.toFixed(2)}, cellSize=${cellSize}`);

    // Special case: very short paths (2 points - just connection)
    if (points.length === 2) {
      // Draw circles along the path with decreasing radius
      const p1 = points[0];
      const p2 = points[1];
      
      // Calculate direction and length
      const dx = p2.x - p1.x;
      const dy = p2.y - p1.y;
      const length = Math.sqrt(dx * dx + dy * dy);
      
      if (length > 0) {
        // Draw circles with decreasing radius
        const circleCount = Math.max(5, Math.ceil(length / (maxWidth * 0.3)));
        
        for (let i = 0; i <= circleCount; i++) {
          const t = i / circleCount;
          const radius = (maxWidth * (1 - t) + minWidth * t) / 2;
          
          const x = p1.x + dx * t;
          const y = p1.y + dy * t;
          
          graphics.beginFill(color, 0.9);
          graphics.drawCircle(x, y, radius);
          graphics.endFill();
        }
      }
      return;
    }

    // Normal case: smooth the path with Catmull-Rom spline
    const smoothPoints = this._smoothPathCatmullRom(points, 0.5, 10);

    // Draw as overlapping circles with varying radius
    // Увеличиваем частоту кругов чтобы избежать пробелов
    for (let i = 0; i < smoothPoints.length; i++) {
      const t = i / (smoothPoints.length - 1);
      // Radius decreases from mouth (t=0) to source (t=1)
      const radius = (maxWidth * (1 - t) + minWidth * t) / 2;

      const point = smoothPoints[i];

      graphics.beginFill(color, 0.9);
      graphics.drawCircle(point.x, point.y, radius);
      graphics.endFill();
      
      // Добавляем промежуточные круги между точками для избежания пробелов
      if (i < smoothPoints.length - 1) {
        const nextPoint = smoothPoints[i + 1];
        const nextT = (i + 1) / (smoothPoints.length - 1);
        const nextRadius = (maxWidth * (1 - nextT) + minWidth * nextT) / 2;
        
        // Вычисляем расстояние между точками
        const dx = nextPoint.x - point.x;
        const dy = nextPoint.y - point.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        // Определяем сколько промежуточных кругов нужно
        const avgRadius = (radius + nextRadius) / 2;
        const extraCircles = Math.ceil(dist / (avgRadius * 0.8)) - 1;
        
        // Рисуем промежуточные круги
        for (let j = 1; j <= extraCircles; j++) {
          const interpT = j / (extraCircles + 1);
          const interpRadius = radius * (1 - interpT) + nextRadius * interpT;
          const interpX = point.x + dx * interpT;
          const interpY = point.y + dy * interpT;
          
          graphics.beginFill(color, 0.9);
          graphics.drawCircle(interpX, interpY, interpRadius);
          graphics.endFill();
        }
      }
    }
  }

  /**
   * Smooth path using Catmull-Rom spline
   * @private
   */
  _smoothPathCatmullRom(points, tension = 0.5, segments = 10) {
    if (points.length < 2) return points;
    if (points.length === 2) return points;

    const smoothed = [];

    // Add first point
    smoothed.push(points[0]);

    // Interpolate between points
    for (let i = 0; i < points.length - 1; i++) {
      const p0 = points[Math.max(0, i - 1)];
      const p1 = points[i];
      const p2 = points[i + 1];
      const p3 = points[Math.min(points.length - 1, i + 2)];

      for (let t = 0; t < segments; t++) {
        const tt = t / segments;
        const tt2 = tt * tt;
        const tt3 = tt2 * tt;

        // Catmull-Rom basis
        const q0 = -tension * tt3 + 2 * tension * tt2 - tension * tt;
        const q1 = (2 - tension) * tt3 + (tension - 3) * tt2 + 1;
        const q2 = (tension - 2) * tt3 + (3 - 2 * tension) * tt2 + tension * tt;
        const q3 = tension * tt3 - tension * tt2;

        const x = p0.x * q0 + p1.x * q1 + p2.x * q2 + p3.x * q3;
        const y = p0.y * q0 + p1.y * q1 + p2.y * q2 + p3.y * q3;

        smoothed.push({ x, y });
      }
    }

    // Add last point
    smoothed.push(points[points.length - 1]);

    return smoothed;
  }

  /**
   * Convert normalized height (0-1) to RGB color
   * Blue (low) -> Green -> Yellow -> Red (high)
   * @private
   */
  _heightToColor(normalized) {
    // Clamp normalized to 0-1 range
    normalized = Math.max(0, Math.min(1, normalized));
    
    let r = 0, g = 0, b = 0;

    if (normalized < 0.25) {
      // Blue to Green
      const t = normalized / 0.25;
      r = 0;
      g = Math.floor(255 * t);
      b = 255;
    } else if (normalized < 0.5) {
      // Green to Yellow
      const t = (normalized - 0.25) / 0.25;
      r = Math.floor(255 * t);
      g = 255;
      b = 0;
    } else if (normalized < 0.75) {
      // Yellow to Orange
      const t = (normalized - 0.5) / 0.25;
      r = 255;
      g = Math.floor(255 * (1 - t * 0.5));
      b = 0;
    } else {
      // Orange to Red
      const t = (normalized - 0.75) / 0.25;
      r = 255;
      g = Math.floor(200 * (1 - t));
      b = 0;
    }
    
    // Apply mask to ensure positive hex value
    return ((r << 16) | (g << 8) | b) & 0xFFFFFF;
  }

}
